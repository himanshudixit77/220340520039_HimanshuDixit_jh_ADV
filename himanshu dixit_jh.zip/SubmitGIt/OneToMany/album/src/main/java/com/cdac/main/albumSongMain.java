package com.cdac.main;

import com.cdac.component.Song;
import com.cdac.component.album;
import com.cdac.dao.genricDao;

public class albumSongMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		album alb=new album();
		alb.setCompnay("zee");
		alb.setName("ranver");
		
		genricDao dao=new genricDao();
		//dao.save(alb);
		//album alb1=(album)dao.fetchById(album.class,1);
		Song song=new Song();
		song.setSinger("arjit");
		song.setTitle("kya hua ");
		song.setAlb(alb);
		dao.save(alb);
		
		
	}

}
