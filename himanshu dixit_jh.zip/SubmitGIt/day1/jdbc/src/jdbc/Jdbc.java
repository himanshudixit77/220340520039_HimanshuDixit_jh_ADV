package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Jdbc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			 Class.forName("com.mysql.cj.jdbc.Driver"); //Load Driver class
			 Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/kanpur", "himanshu1", "cdac");  //Connection with DB
			 Statement s = con.createStatement();
			int rows = s.executeUpdate("insert into book1 values(7,'Nipun',500)");
//			 int rows = s.executeUpdate("update book set price=500 where bookid=5");
		 if(rows>0) {
				 System.out.println("Inserted successfully");
		 }else {
			 System.out.println("Some error occured");
		 }
			 ResultSet rs = s.executeQuery("select * from book1");
			 while(rs.next()) {
				 int bookid = rs.getInt("bookid");
				 String bookname = rs.getString("bookname");
				 int price = rs.getInt("price");
				 System.out.println(bookid+" "+bookname+" "+price);
			 }
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
