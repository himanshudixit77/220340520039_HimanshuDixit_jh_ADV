package com.cdac.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="address")
public class Address {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
@Column(name="addres_id")
private int id;

public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getAdddres() {
	return adddres;
}
public void setAdddres(String adddres) {
	this.adddres = adddres;
}
public int getPincode() {
	return pincode;
}
public void setPincode(int pincode) {
	this.pincode = pincode;
}
public String getState() {
	return State;
}
public void setState(String state) {
	State = state;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
private String adddres;
private int pincode;
private String State;
private String city;
}
