package com.cdac.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cdac.dao.Dao;
import com.cdac.entity.USER;

@WebServlet("/User")
public class User extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		USER obj=new USER();
		
		obj.setName(request.getParameter("name"));
		obj.setAge(Integer.parseInt(request.getParameter("age")));
		obj.setDob(LocalDate.parse(request.getParameter("dob")));  
		
		Dao dao=new Dao();
		dao.add(obj);
		PrintWriter out=response.getWriter();
		out.write("<h1> inserted properly</h1>");
		
	}
}
