package com.cdac.java;



import java.io.PrintWriter;

import com.cdac.dao.PersonDao;
import com.cdac.entity.Person;
import com.cdac.entity.Residence;

public class PersonResidence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Person p=new Person();
		Residence resi=new Residence();
		p.setName("himnshu");
		resi.setAddress("saket nagar");
		
		p.setResidence(resi);
		resi.setPerson(p);
		
		PersonDao dao=new PersonDao();
		dao.add(p);
		
	}

}
