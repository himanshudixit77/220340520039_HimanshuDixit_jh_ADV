package com.cdac.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cdac.entity.Person;
import com.cdac.entity.Residence;

public class ResidenceDao {

	public void add(Residence resi) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("team4");
		EntityManager em = emf.createEntityManager();
		EntityTransaction t = em.getTransaction();
		t.begin();
		em.persist(resi);
		t.commit();
		emf.close();
	}
	
	}


