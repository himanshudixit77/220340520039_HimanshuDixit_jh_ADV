package com.cdac.simplejava;

import java.util.List;

import com.cdac.dao.PersonAddressDao;
import com.cdac.entity.Address;
import com.cdac.entity.Person;

public class SimpleFetch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Person person =new Person();
		PersonAddressDao dao =new PersonAddressDao();
		/*List<Person>list=dao.fetchByAge(25);
		for(Person p:list)
			System.out.println(p.getId()+" "+p.getAge()+" "+p.getName());*/
		
		Address add =new Address();
		/*List<Address>list=dao.fetchByState("up");
		for(Address p:list)
			System.out.println(p.getId()+" "+p.getResidence()+" "+p.getPincode());*/
		
		List<Person>list=dao.fetchByPincode(208014);
		for(Person q:list)
			System.out.println(q.getId()+" "+q.getAge()+" "+q.getName());
	}
	}

