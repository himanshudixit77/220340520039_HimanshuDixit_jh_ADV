package com.cdac.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cdac.entity.Address;
import com.cdac.entity.Person;


public class PersonAddressDao {

	public void add(Person person) {
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("team4");
			EntityManager em = emf.createEntityManager();
			EntityTransaction t = em.getTransaction();
			t.begin();
			em.persist(person);
			t.commit();
			emf.close();
		}
	public void update(Person person) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("team4");
		EntityManager em = emf.createEntityManager();
		EntityTransaction t = em.getTransaction();
		t.begin();
		em.merge(person);
		t.commit();
		emf.close();
	}
		 public void add(Address add) {
				EntityManagerFactory emf = Persistence.createEntityManagerFactory("team4");
				EntityManager em = emf.createEntityManager();
				EntityTransaction t = em.getTransaction();
				t.begin();
				em.persist(add);
				t.commit();
				emf.close();
			}
			 
	
		
			public  Address fetchAddress(int id) {
				 EntityManagerFactory emf = Persistence.createEntityManagerFactory("team4");
					EntityManager em = emf.createEntityManager();

					//find method generates select query where pk = ?
					Address addr = em.find(Address.class, id);
					
					emf.close();

					return addr;	
				}
			public  Person fetchPerson(int id) {
				 EntityManagerFactory emf = Persistence.createEntityManagerFactory("team4");
					EntityManager em = emf.createEntityManager();

					//find method generates select query where pk = ?
					Person p = em.find(Person.class, id);
					
					emf.close();

					return p;	
				}
     public List<Person> fetchByAge(int age)
     {
    	 EntityManagerFactory emf = Persistence.createEntityManagerFactory("team4");
 		EntityManager em = emf.createEntityManager();
 		Query q = em.createQuery("from Person p where p.age=:age");
 		q.setParameter("age",age);
 		List<Person> list = q.getResultList();
 		emf.close();
 		return list;
 	}
	public List<Address> fetchByState(String state) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("team4");
 		EntityManager em = emf.createEntityManager();
 		Query q = em.createQuery("from Address p where p.State=:state");
 		q.setParameter("state",state);
 		List<Address> list = q.getResultList();
 		emf.close();
 		return list;
	}
	public List<Person> fetchByPincode(int pin) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("team4");
 		EntityManager em = emf.createEntityManager();
 		
 		Query q = em.createQuery("select p from Person p join p.address a  where a.pincode= :pincode");
 		q.setParameter("pincode",pin);
 		List<Person> list = q.getResultList();
 		emf.close();
 		return list;
	}
     }

