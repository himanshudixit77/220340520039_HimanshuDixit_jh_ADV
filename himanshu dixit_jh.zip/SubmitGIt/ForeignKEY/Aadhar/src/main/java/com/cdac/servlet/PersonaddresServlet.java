package com.cdac.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cdac.dao.PersonAddressDao;
import com.cdac.entity.Address;
import com.cdac.entity.Person;

/**
 * Servlet implementation class PersonaddresServlet
 */
@WebServlet("/person")
public class PersonaddresServlet extends HttpServlet {
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		Person person =new Person();
		person.setName(request.getParameter("name"));
		person.setAge(Integer.parseInt(request.getParameter("age")));
		person.setDob(LocalDate.parse(request.getParameter("dob")));
		
		PersonAddressDao dao =new PersonAddressDao();
		
		Address address =new Address();
		address.setPincode(Integer.parseInt(request.getParameter("pincode")));
		address.setResidence(request.getParameter("residence"));
		address.setState(request.getParameter("state"));
		//dao.add(address);
		
  /*Address a=dao.fetchAddress(1);
  Person p=dao.fetchPerson(1);
  p.setAddress(a);
  dao.update(p);*/
		
		/*person.setAddress(address);
		dao.add(person);*/
		
		/*PrintWriter out =response.getWriter();
		out.write("<h1>inserted succesfully</h1>");*/
		
		List<Person>list=dao.fetchByAge(25);
		for(Person p:list)
			System.out.println(p.getId()+" "+p.getAge()+" "+p.getName());
	}

}
