package form.cdac;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
 * Servlet implementation class form
 */
@WebServlet("/form")
public class form extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		String location=request.getParameter("location");
		String action1=request.getParameter("action");
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/kanpur", "himanshu1", "cdac");
			Statement s=con.createStatement();
			 if(action1.equals("register")) {
		
				 PreparedStatement st = con.prepareStatement("insert into form(name, email,password,location) values(?, ?, ?, ?)");
				st.setString(1, name); //substituting ? with actual value
				st.setString(2, email);
				st.setString(3, location);
				st.setString(4, password);
				st.executeUpdate();
				out.write("<html><body>");
				out.write("<h1>sum is</h1>");
				out.write("</body></html>");
				con.close();}
				
		}catch(Exception e) {e.printStackTrace();}	
	}
}
