package day2.cdac;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class form
 */
@WebServlet("/form")
public class form extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	try {
		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String mobile=request.getParameter("mobile");
		String location=request.getParameter("location");
		String password=request.getParameter("password");
		Class.forName("com.mysql.cj.jdbc.Driver"); //Load Driver class
 Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/kanpur", "himanshu1", "cdac");  //Connection with DB
 PreparedStatement st = con.prepareStatement("insert into form(name, email, mobile, location, password) values(?, ?, ?, ?, ?)");
	st.setString(1, name); //substituting ? with actual value
	st.setString(2, email);
	st.setString(3, mobile);
	st.setString(4, location);
	st.setString(5, password);
	st.executeUpdate();
	con.close();
	
	
	PrintWriter out = response.getWriter();
	out.write("<html><body>");
	out.write("<h1>Registration successful!</h1>");
	out.write("</body></html>");
}
catch(Exception e) {
	e.printStackTrace();
}
	


}

}
