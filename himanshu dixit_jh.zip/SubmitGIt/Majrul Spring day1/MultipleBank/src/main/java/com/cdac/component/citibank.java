package com.cdac.component;

import org.springframework.stereotype.Component;

@Component
public class citibank implements Bank {

	public boolean isAccountNumber(int anco) {
		// TODO Auto-generated method stub
         if(anco==1011)
        	 return true;
         return false;
	}

	public void Withdraw(int anco, int accno, double amount) {
		// TODO Auto-generated method stub
		System.out.println("city bank transfered");
	}

}
