package com.cdac.component;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class dao {
	
	public static void main(String[] args) {
		
		ApplicationContext ctx =new ClassPathXmlApplicationContext("spring.xml");
		
		Atm objAtm=(Atm)ctx.getBean("hdfc");
		objAtm.Withdraw(101,101585,8500);
	}

}
