package com.cdac.component;

import org.springframework.stereotype.Component;

@Component("hello1")
public class hello {

	public void wish()
	{
		System.out.println("hee bro welcome in hello class");
	}
}
