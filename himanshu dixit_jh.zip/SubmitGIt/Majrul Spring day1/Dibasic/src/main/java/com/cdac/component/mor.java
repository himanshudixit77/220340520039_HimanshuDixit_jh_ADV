package com.cdac.component;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("mor")
public class mor {
	
	@Autowired 
	private hello hellobaby ;
	
	public void abc()
	{
		hellobaby.wish();
	}

}
