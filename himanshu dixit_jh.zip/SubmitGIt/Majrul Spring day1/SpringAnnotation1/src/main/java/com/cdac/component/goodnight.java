package com.cdac.component;

import org.springframework.stereotype.Component;

@Component("cal")
public class goodnight {

	public int cal(int x,int y)
	{
		return x+y;
	}
}
