package com.cdac.component;

import org.springframework.stereotype.Component;

@Component("hii")
public class helloWorld {

	public void name() {
	System.out.println("hii himanshu here xarvis here");	
	}
}
