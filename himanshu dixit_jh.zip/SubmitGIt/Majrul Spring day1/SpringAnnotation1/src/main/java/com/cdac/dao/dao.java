package com.cdac.dao;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cdac.component.goodnight;
import com.cdac.component.helloWorld;

public class dao {

	public static void main(String[] args) {
		
		ApplicationContext ctx =new ClassPathXmlApplicationContext("Spring.xml");
		helloWorld obj =(helloWorld)ctx.getBean("hii");
	obj.name();
	
	goodnight goodnight=(goodnight)ctx.getBean("cal");
	System.out.println(goodnight.cal(5, 10));
	
	}
}
