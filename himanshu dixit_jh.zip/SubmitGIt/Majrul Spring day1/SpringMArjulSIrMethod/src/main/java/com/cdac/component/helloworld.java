package com.cdac.component;

public class helloworld {

	public String name() {
		return "helloworld";
	}
	

	}
