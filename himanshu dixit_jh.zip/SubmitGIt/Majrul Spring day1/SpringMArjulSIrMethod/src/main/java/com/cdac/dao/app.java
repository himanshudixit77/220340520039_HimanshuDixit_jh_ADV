package com.cdac.dao;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cdac.component.helloworld;

public class app {

	public static void main(String[] args) {
		ApplicationContext ctx =new ClassPathXmlApplicationContext("mySpring.xml");
helloworld obj =(helloworld)ctx.getBean("hello1");
System.out.println(obj.name());
	
	
	}
}
