package com.cdac.component;


public interface Bank {

	public void Withdraw(int accno,double amount);
}
