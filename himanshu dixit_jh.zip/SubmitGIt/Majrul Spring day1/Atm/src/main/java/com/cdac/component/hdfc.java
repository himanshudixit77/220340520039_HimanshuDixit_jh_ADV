package com.cdac.component;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class hdfc implements Atm{

	@Autowired
	private Bank bank;
	public void Withdraw(int accno, double amount) {
		// TODO Auto-generated method stub
	System.out.println("welcome to hdfc bank atm");
		bank.Withdraw( 88, 5000);
	}

}
