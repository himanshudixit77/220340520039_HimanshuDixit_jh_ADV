package com.cdac.component;

import org.springframework.stereotype.Component;

@Component
public class citibank implements Bank {

	public void Withdraw( int accno, double amount) {
		// TODO Auto-generated method stub
		System.out.println("city bank transfered");
	}

}
