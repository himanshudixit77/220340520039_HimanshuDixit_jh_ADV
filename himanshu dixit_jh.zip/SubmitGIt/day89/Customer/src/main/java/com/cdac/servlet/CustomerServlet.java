package com.cdac.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cdac.dao.CustomerDao;

import com.cdac.entity.Customer;

@WebServlet("/customer")
public class CustomerServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(request.getParameter("Insert")!=null) {
			
	Customer uT =new Customer();
	uT.setEmail(request.getParameter("email"));
	uT.setAge(Integer.parseInt(request.getParameter("age")));
	uT.setName(request.getParameter("name"));
	uT.setPassword(request.getParameter("password"));
	
	
	CustomerDao dao =new CustomerDao();
	dao.add(uT);
	
	PrintWriter out =response.getWriter();
	out.write("<h1>inserted succeful</h1>");
		}
		
		if(request.getParameter("login")!=null)
		{
			 response.sendRedirect("login.html");
			
		}
		}
		
	}
