package com.cdac.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cdac.entity.Customer;

public class CustomerDao {
	
	
	public void add(Customer ut)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("team4");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();

		em.persist(ut); //persist method will generate insert query
		
		tx.commit();
		emf.close();
	}
       

	public Customer checkCredentials(String email,String password) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("team4");
		EntityManager em = emf.createEntityManager();
		Query q = em.createQuery("from Customer where email=:email and password=:password");
		q.setParameter("email", email);
		q.setParameter("password", password);
		List<Customer> userList = q.getResultList();
		
		if(userList != null && userList.size()>0) {
			return userList.get(0);
		}
		return null;
	}

	

}


