package com.cdac.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cdac.dao.CustomerDao;
import com.cdac.entity.Customer;

@WebServlet("/login")
public class login extends HttpServlet {
	 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		//Customer uT =new Customer();
		
		String email =request.getParameter("email");
	   String password=	request.getParameter("password");
		
		CustomerDao dao =new CustomerDao();
		
		Customer customer =dao.checkCredentials(email,password);
		
		PrintWriter out =response.getWriter();
		if(customer!=null)
		{
			out.write("<h1>login properly</h1>");
		}
		
	}

}
