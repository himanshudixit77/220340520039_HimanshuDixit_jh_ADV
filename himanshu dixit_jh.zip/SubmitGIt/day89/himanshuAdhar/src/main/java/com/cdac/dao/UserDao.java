package com.cdac.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cdac.entity.UserTable;


import antlr.collections.List;

public class UserDao {
	
	
	public void add(UserTable ut)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("team4");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();

		em.persist(ut); //persist method will generate insert query
		
		tx.commit();
		emf.close();
	}

	public UserTable fetch(Integer adhar) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("dbPersistence");
		EntityManager em = emf.createEntityManager();
		UserTable s = em.find(UserTable.class, adhar);
		emf.close();
		return s;
	}


}


