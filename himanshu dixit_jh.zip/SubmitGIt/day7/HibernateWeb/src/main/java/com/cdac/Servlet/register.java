package com.cdac.Servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cdac.dao.userDao;
import com.cdac.entity.user;

/**
 * Servlet implementation class register
 */
@WebServlet("/register")
public class register extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		
			
		int empno=Integer.parseInt(request.getParameter("empno"));
		
		String name=request.getParameter("name");
		
		int Salary=Integer.parseInt(request.getParameter("Salary"));
		
		String location=request.getParameter("location");
		
		 
		user obj=new user(empno,name,Salary,location);
		
		userDao dao=new userDao();
		dao.add(obj);
	PrintWriter out=response.getWriter();
	out.write("<h1>heee inserted</h1>");
		
		
		
		
	}

}
