package com.cdac.dao;



import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cdac.entity.user;

public class userDao {

	
	public void add(user user1)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
	    EntityManager em = emf.createEntityManager();
	    EntityTransaction tx = em.getTransaction();
	    tx.begin();
	    em.persist(user1);
	    
	    tx.commit();
	    
	    emf.close();
	    
}
	}

