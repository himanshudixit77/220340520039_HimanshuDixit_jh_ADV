package com.cdac.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.ProcessBuilder.Redirect;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cdac.dao.CustomerDao;
import com.cdac.entity.Customer;



/**
 * Servlet implementation class login
 */
@WebServlet("/login")
public class login extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	
		Customer customer=new Customer();
String name=	request.getParameter("name");	
String location=request.getParameter("location");
		
		CustomerDao dao = new CustomerDao();
		Customer list1=dao.fetchNameandLocation(name,location);
		if(list1!=null )
			response.sendRedirect("welcome.html");

	}
}
		
