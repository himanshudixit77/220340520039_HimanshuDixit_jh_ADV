package com.cdac.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cdac.entity.Customer;



public class CustomerDao {
	public void add(Customer user1)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("team4");
	    EntityManager em = emf.createEntityManager();
	    EntityTransaction tx = em.getTransaction();
	    tx.begin();
	    em.persist(user1);
	    
	    tx.commit();
	    
	    emf.close();	    
}
	public Customer fetchNameandLocation(String name,String location){
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
	    EntityManager em = emf.createEntityManager();
	   Query q=em.createQuery("select e  from Employee e where e.name = :name  and e.location=:location");
	   q.setParameter("name",name);//hql 
	   q.setParameter("location",location);//hql 
	   List<Customer> list= q.getResultList();
	   if(list!=null && list.size()>0)
	   {
	    return list.get(0); 
	}
	   return null;
}
}

	

